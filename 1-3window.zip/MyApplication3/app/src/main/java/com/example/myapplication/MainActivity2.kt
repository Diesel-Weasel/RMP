package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import java.lang.Exception

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val edTex2:EditText= findViewById(R.id.editT2)
        val edTex3:EditText= findViewById(R.id.editT3)
        val edTex4:EditText= findViewById(R.id.editT4)
        val edTex5:EditText= findViewById(R.id.editT5)
        val solver:Button= findViewById(R.id.button3)
        val buNe2: Button = findViewById(R.id.bnext2)

        solver.setOnClickListener(){

            try {
                val num1:Double = edTex4.text.toString().toDouble()
                val num2:Double = edTex3.text.toString().toDouble()
                val oper:String = edTex5.text.toString()
                val result:Double

                when (oper) {
                    "+" -> {
                        result= num1 + num2
                        edTex2.setText("=" + result.toString())
                    }
                    "-" -> {
                        result= num1 - num2
                        edTex2.setText("=" + result.toString())
                    }
                    "*" -> {
                        result= num1 * num2
                        edTex2.setText("=" + result.toString())
                    }
                    "/" -> {
                        if (num2==0.0) edTex2.setText("error")
                        else {
                            result= num1 / num2
                            edTex2.setText("=" + result.toString())
                        }
                    }
                    else -> {
                        edTex2.setText("error")
                    }
                }

            }catch (e: Exception){
                edTex2.setText("error")
            }
        }

        buNe2.setOnClickListener(){
            val inte2: Intent = Intent( this, MainActivity3::class.java)
            startActivity(inte2)
        }
    }
}