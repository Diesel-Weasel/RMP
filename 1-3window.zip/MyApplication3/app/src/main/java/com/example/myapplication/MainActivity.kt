package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tex1:TextView= findViewById(R.id.text1)
        val edtex1:EditText= findViewById(R.id.editT1)
        val bu1:Button= findViewById(R.id.button)
        val bu2:Button= findViewById(R.id.bnext1)

        bu1.setOnClickListener(){
            tex1.text= edtex1.text
        }

        bu2.setOnClickListener(){
            val inte: Intent = Intent( this, MainActivity2::class.java)
            startActivity(inte)
        }

    }
}