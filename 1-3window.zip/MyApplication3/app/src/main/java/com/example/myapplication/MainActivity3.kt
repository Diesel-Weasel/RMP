package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Layout
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {

    private var xDelta = 0
    private var yDelta = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val layouP = RelativeLayout.LayoutParams(200, 100)

        val swipeT: TextView = findViewById(R.id.textSwipe)
        val buNe3: Button = findViewById(R.id.bnext3)
        val restart: Button = findViewById(R.id.bre)

        swipeT.layoutParams = layouP

        buNe3.setOnClickListener(){
            val inte3: Intent = Intent( this, MainActivity::class.java)
            startActivity(inte3)
        }

        restart.setOnClickListener(){
            //swipeT.layoutParams.leftMargin = x - xDelta
            //swipeT.layoutParams.topMargin = y - yDelta
        }

        swipeT.setOnTouchListener{v,event->
            val action=event.action
            when(action) {
                MotionEvent.ACTION_UP -> {

                }
                MotionEvent.ACTION_DOWN -> {
                    val x = event.rawX.toInt()
                    val y = event.rawY.toInt()
                    val lParams = v.layoutParams as RelativeLayout.LayoutParams
                    xDelta = x - lParams.leftMargin
                    yDelta = y - lParams.topMargin
                }
                MotionEvent.ACTION_MOVE -> {
                    val x = event.rawX.toInt()
                    val y = event.rawY.toInt()
                    val layoutParams = v.layoutParams as RelativeLayout.LayoutParams
                    layoutParams.leftMargin = x - xDelta
                    layoutParams.topMargin = y - yDelta
                    layoutParams.rightMargin = 0
                    layoutParams.bottomMargin = 0
                    v.layoutParams = layoutParams
                }

                else -> {

                }
            }
            true
        }
    }
}