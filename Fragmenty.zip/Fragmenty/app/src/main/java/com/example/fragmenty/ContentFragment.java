package com.example.fragmenty;

import androidx.fragment.app.Fragment;

public class ContentFragment extends Fragment{

    public ContentFragment(){
        super(R.layout.fragment_content);
    }
}
