package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.swt)
        val vvod:TextView = findViewById(R.id.inputTxt)
        val swed:EditText = findViewById(R.id.switchedText)
        val btnsw:Button = findViewById(R.id.btnSwitch)
        val btnext:Button = findViewById(R.id.nextWin)

        btnsw.setOnClickListener(){
            vvod.text= swed.text
        }

        btnext.setOnClickListener(){
            val nexto2: Intent = Intent( this, MainActivity2::class.java)
            startActivity(nexto2)
        }

    }
}