package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import java.lang.Exception

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.calc)

        val first:EditText = findViewById(R.id.firstChislo)
        val znak:EditText = findViewById(R.id.txtznak)
        val seccond:EditText = findViewById(R.id.secChislo)
        val res:EditText = findViewById(R.id.txtresult)
        val calc:Button = findViewById(R.id.btnCalc)
        val btnNext:Button = findViewById(R.id.nextWin3)

        calc.setOnClickListener(){

            try {
                val firstNum:Double = first.text.toString().toDouble()
                val seccondNum:Double = seccond.text.toString().toDouble()
                val operation:String = znak.text.toString()
                val result:Double

                when (operation) {
                    "+" -> {
                        result= firstNum + seccondNum
                        first.setText("=" + result.toString())
                    }
                    "-" -> {
                        result= firstNum - seccondNum
                        first.setText("=" + result.toString())
                    }
                    "*" -> {
                        result= firstNum * seccondNum
                        first.setText("=" + result.toString())
                    }
                    "/" -> {
                        if (seccondNum==0.0) first.setText("ERROR")
                        else {
                            result= firstNum / seccondNum
                            first.setText("=" + result.toString())
                        }
                    }
                    else -> {
                        first.setText("ERROR")
                    }
                }

            }catch (e: Exception){
                first.setText("ERROR")
            }
        }

        btnNext.setOnClickListener(){
            val into3: Intent = Intent( this, MainActivity3::class.java)
            startActivity(into3)
        }
    }
}