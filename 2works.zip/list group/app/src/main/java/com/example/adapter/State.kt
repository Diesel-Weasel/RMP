package com.example.adapter
class State(var first: String,
            var sec: String,
            var mid: String,
            var count: Int) {

    lateinit var name: String
    lateinit var secname: String
    lateinit var midname: String
    private var countrie = 0 // ресурс флага
    init {
        this.name = first
        this.secname = sec
        this.midname = mid
        countrie = count
    }



    fun getFName(): String {
        return name
    }

    fun setFName(first: String) {
        this.name = first
    }



    fun getIName(): String {
        return secname
    }

    fun setIName(sec: String) {
        this.secname = sec
    }



    fun getOName(): String {
        return midname
    }

    fun setOName(mid: String) {
        this.midname = mid
    }



    fun getImage(): Int {
        return countrie
    }

    fun setFlagResource(count: Int) {
        this.countrie = count
    }
}