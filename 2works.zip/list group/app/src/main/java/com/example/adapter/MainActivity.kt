package com.example.adapter

import android.os.Bundle
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    var states = ArrayList<State>()
    lateinit var countriesList: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        // начальная инициализация списка
        setInitialData()
        // получаем элемент ListView
        countriesList = findViewById(R.id.countriesList)
        // создаем адаптер
        val stateAdapter = StateAdapter(this, R.layout.list_item, states)
        // устанавливаем адаптер
        countriesList.setAdapter(stateAdapter)
        // слушатель выбора в списке
        /*val itemListener =
            OnItemClickListener { parent, v, position, id -> // получаем выбранный пункт
                val selectedState = parent.getItemAtPosition(position) as State
                Toast.makeText(
                    applicationContext, "Был выбран пункт " + selectedState.getFName(),
                    Toast.LENGTH_SHORT
                ).show()
            }
        countriesList.setOnItemClickListener(itemListener)*/
    }

    private fun setInitialData() {
        states.add(State("Николаев", "Анатолий", "Николаевич",R.drawable.img1))
        states.add(State("Николаев", "Анатолий", "Николаевич", R.drawable.img2))
        states.add(State("Николаев", "Анатолий", "Николаевич", R.drawable.img3))
        states.add(State("Николаев", "Анатолий", "Николаевич", R.drawable.img4))
        states.add(State("Николаев", "Анатолий", "Николаевич", R.drawable.img6))
    }
}