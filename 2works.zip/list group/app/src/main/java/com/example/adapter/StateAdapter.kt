package com.example.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView


class StateAdapter(context: Context?, private val layout: Int, private val states: List<State>) :
    ArrayAdapter<State?>(context!!, layout, states) {
    private val inflat: LayoutInflater

    init {
        inflat = LayoutInflater.from(context)
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = inflat.inflate(layout, parent, false)
        val flagView = view.findViewById<ImageView>(R.id.img)
        val namevw = view.findViewById<TextView>(R.id.name)
        val midnamevw = view.findViewById<TextView>(R.id.midname)
        val secnamevw = view.findViewById<TextView>(R.id.secname)
        val state = states[position]
        flagView.setImageResource(state.getImage())
        namevw.setText(state.getFName())
        midnamevw.setText(state.getOName())
        secnamevw.setText(state.getIName())
        return view
    }
}