package list

class News {
    val title: String,
    val description: String,
    val linkImage: String,
    val additionalInfo: String,
}