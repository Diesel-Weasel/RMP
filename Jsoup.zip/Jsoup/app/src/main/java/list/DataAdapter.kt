package list

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class DataAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val listNews = mutableListOf<News>()

    override fun onCreateViewHolder(parent: ViewGroup, pos: Int): ViewHolder {
        val view: LayoutInflater = LayoutInflater.from(parent)
    }

    override fun getItemCount(): Int {
    }

    override fun onBindViewHolder(holder: ViewHolder, pos: Int) {
    }

    fun  set(list: MutableList<News>) {
        this.listNews.clear()
        this.listNews.addAll(list)
        notifyDataSetChanged()
    }

}