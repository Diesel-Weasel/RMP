package com.example.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView


class StateAdapter(context: Context?, private val layout: Int, private val states: List<State>) :
    ArrayAdapter<State?>(context!!, layout, states) {
    private val inflater: LayoutInflater

    init {
        inflater = LayoutInflater.from(context)
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = inflater.inflate(layout, parent, false)
        val flagView = view.findViewById<ImageView>(R.id.img)
        val fnameView = view.findViewById<TextView>(R.id.fname)
        val onameView = view.findViewById<TextView>(R.id.oname)
        val inameView = view.findViewById<TextView>(R.id.iname)
        val state = states[position]
        flagView.setImageResource(state.getImage())
        fnameView.setText(state.getFName())
        onameView.setText(state.getOName())
        inameView.setText(state.getIName())
        return view
    }
}