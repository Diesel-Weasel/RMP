package com.example.adapter
class State(var fn:String,var ina:String,var on:String,var fi:Int) {
    lateinit var fname: String
    lateinit var iname: String
    lateinit var oname: String
    private var flagimg = 0 // ресурс флага
    init {
        this.fname = fn
        this.iname = ina
        this.oname = on
        flagimg = fi
    }
    fun getFName(): String {
        return fname
    }
    fun setFName(fna: String) {
        this.fname = fna
    }
    fun getIName(): String {
        return iname
    }
    fun setIName(inaa: String) {
        this.iname = inaa
    }
    fun getOName(): String {
        return oname
    }
    fun setOName(ona: String) {
        this.oname = ona
    }
    fun getImage(): Int {
        return flagimg
    }
    fun setFlagResource(flagResource: Int) {
        this.flagimg = flagResource
    }
}